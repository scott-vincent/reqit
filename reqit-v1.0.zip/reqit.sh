dotnet reqit/reqit.dll $*
